"use client";

import { useState } from "react";
import type { UrchinReport } from "@/types";

interface UrchinReportFormProps {
  latitude: number;
  longitude: number;
  onSubmit: (report: Omit<UrchinReport, "id" | "timestamp">) => void;
  onCancel: () => void;
}

export default function UrchinReportForm({
  latitude,
  longitude,
  onSubmit,
  onCancel,
}: UrchinReportFormProps) {
  const [name, setName] = useState("");
  const [count, setCount] = useState("");
  const [error, setError] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const trimmedName = name.trim();
    const parsedCount = parseInt(count, 10);

    if (!trimmedName) {
      setError("Please enter your name.");
      return;
    }
    if (!count || isNaN(parsedCount) || parsedCount < 1) {
      setError("Please enter a valid urchin count (minimum 1).");
      return;
    }

    onSubmit({ name: trimmedName, latitude, longitude, urchin_count: parsedCount });
  }

  return (
    <div className="urchin-modal-overlay">
      <div className="urchin-modal">
        <h2 className="urchin-modal-title">Log Urchin Removal</h2>
        <p className="urchin-modal-location">
          {latitude.toFixed(4)}, {longitude.toFixed(4)}
        </p>

        <form onSubmit={handleSubmit} className="urchin-form">
          <label className="urchin-label">
            Your Name
            <input
              className="urchin-input"
              type="text"
              placeholder="e.g. Jane Smith"
              value={name}
              onChange={(e) => { setName(e.target.value); setError(""); }}
              autoFocus
            />
          </label>

          <label className="urchin-label">
            Urchins Smashed
            <input
              className="urchin-input"
              type="number"
              placeholder="e.g. 42"
              min={1}
              value={count}
              onChange={(e) => { setCount(e.target.value); setError(""); }}
            />
          </label>

          {error && <p className="urchin-error">{error}</p>}

          <div className="urchin-actions">
            <button type="button" className="btn-cancel" onClick={onCancel}>
              Cancel
            </button>
            <button type="submit" className="btn-submit">
              Save Report
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
