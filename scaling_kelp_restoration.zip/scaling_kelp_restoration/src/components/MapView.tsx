"use client";

import { useMemo } from "react";
import {
  MapContainer,
  TileLayer,
  CircleMarker,
  Tooltip,
  Marker,
  useMapEvents,
} from "react-leaflet";
import L from "leaflet";
import type { DataPoint, LayerName, LayerState, UrchinReport } from "@/types";
import { interpolateColor } from "@/utils/color";
import "leaflet/dist/leaflet.css";

interface MapViewProps {
  data: DataPoint[];
  layers: LayerState;
  reportMode: boolean;
  urchinLayerVisible: boolean;
  urchinReports: UrchinReport[];
  onLocationSelected: (lat: number, lng: number) => void;
}

const CENTER: [number, number] = [34.5, -120.0];
const ZOOM = 7;
const MIN_RADIUS = 3;
const MAX_RADIUS = 10;
const STROKE_WEIGHT = 2.5;

const FLAG_ICON = L.divIcon({
  html: `<svg xmlns="http://www.w3.org/2000/svg" width="22" height="30" viewBox="0 0 22 30">
    <line x1="3" y1="2" x2="3" y2="28" stroke="#ffffff" stroke-width="2" stroke-linecap="round"/>
    <polygon points="3,2 19,7 3,13" fill="#a855f7" stroke="#ffffff" stroke-width="1.2"/>
    <circle cx="3" cy="28" r="2.5" fill="#a855f7" stroke="#ffffff" stroke-width="1.5"/>
  </svg>`,
  className: "",
  iconSize: [22, 30],
  iconAnchor: [3, 28],
  tooltipAnchor: [10, -14],
});

function findNearestPoint(data: DataPoint[], lat: number, lng: number): DataPoint | null {
  if (data.length === 0) return null;
  let nearest = data[0];
  let minDist = Infinity;
  for (const point of data) {
    const d = (point.latitude - lat) ** 2 + (point.longitude - lng) ** 2;
    if (d < minDist) {
      minDist = d;
      nearest = point;
    }
  }
  return nearest;
}

function MapClickHandler({
  data,
  reportMode,
  onLocationSelected,
}: {
  data: DataPoint[];
  reportMode: boolean;
  onLocationSelected: (lat: number, lng: number) => void;
}) {
  useMapEvents({
    click(e) {
      if (!reportMode) return;
      const nearest = findNearestPoint(data, e.latlng.lat, e.latlng.lng);
      if (nearest) {
        onLocationSelected(nearest.latitude, nearest.longitude);
      } else {
        onLocationSelected(e.latlng.lat, e.latlng.lng);
      }
    },
  });
  return null;
}

export default function MapView({
  data,
  layers,
  reportMode,
  urchinLayerVisible,
  urchinReports,
  onLocationSelected,
}: MapViewProps) {
  const visibleLayers = useMemo(() => {
    return (Object.entries(layers) as [LayerName, (typeof layers)[LayerName]][])
      .filter(([, config]) => config.visible)
      .reverse();
  }, [layers]);

  const maxValues = useMemo(() => {
    const maxes = {
      kelp_biomass_kg_2025: 0,
      kelp_biomass_kg_past_2015: 0,
      temperature: 0,
      salinity: 0,
      ocean_current: 0,
      composite_score: 0,
    };
    for (const p of data) {
      for (const key of Object.keys(maxes) as (keyof typeof maxes)[]) {
        if (p[key] > maxes[key]) maxes[key] = p[key];
      }
    }
    for (const key of Object.keys(maxes) as (keyof typeof maxes)[]) {
      if (maxes[key] === 0) maxes[key] = 1;
    }
    return maxes;
  }, [data]);

  return (
    <MapContainer
      center={CENTER}
      zoom={ZOOM}
      style={{ width: "100%", height: "100%", cursor: reportMode ? "crosshair" : "" }}
      zoomControl={true}
    >
      <TileLayer
        attribution='&copy; <a href="https://carto.com/">CARTO</a>'
        url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
      />

      <MapClickHandler
        data={data}
        reportMode={reportMode}
        onLocationSelected={onLocationSelected}
      />

      {data.length > 0 &&
        visibleLayers.map(([layerName, config]) =>
          data.map((point, i) => {
            const raw = point[config.field] as number;
            const maxVal = maxValues[config.field as keyof typeof maxValues] ?? 1;
            const normalized = Math.min(raw / maxVal, 1);
            const color = interpolateColor(
              config.colorLow,
              config.colorHigh,
              normalized
            );
            const radius = MIN_RADIUS + normalized * (MAX_RADIUS - MIN_RADIUS);

            return (
              <CircleMarker
                key={`${layerName}-${i}`}
                center={[point.latitude, point.longitude]}
                radius={radius}
                pathOptions={{
                  fillColor: color,
                  fillOpacity: 0.5,
                  color: color,
                  weight: STROKE_WEIGHT,
                  opacity: 1,
                }}
              >
                <Tooltip className="point-tooltip">
                  <strong>
                    {point.latitude.toFixed(4)}, {point.longitude.toFixed(4)}
                  </strong>
                  Kelp 2025: {point.kelp_biomass_kg_2025.toLocaleString()} kg
                  <br />
                  Kelp 2015: {point.kelp_biomass_kg_past_2015.toLocaleString()} kg
                  <br />
                  Temp: {point.temperature.toFixed(1)}°C | Salinity: {point.salinity.toFixed(1)}
                  <br />
                  Current: {point.ocean_current.toFixed(3)} | Composite: {point.composite_score.toFixed(3)}
                </Tooltip>
              </CircleMarker>
            );
          })
        )}

      {urchinLayerVisible &&
        urchinReports.map((report) => (
          <Marker
            key={report.id}
            position={[report.latitude, report.longitude]}
            icon={FLAG_ICON}
          >
            <Tooltip className="point-tooltip" direction="right">
              <strong>{report.name}</strong>
              {report.urchin_count.toLocaleString()} urchins smashed
              <br />
              {report.latitude.toFixed(4)}, {report.longitude.toFixed(4)}
              <br />
              <span style={{ fontSize: "10px", opacity: 0.7 }}>
                {new Date(report.timestamp).toLocaleString()}
              </span>
            </Tooltip>
          </Marker>
        ))}
    </MapContainer>
  );
}
