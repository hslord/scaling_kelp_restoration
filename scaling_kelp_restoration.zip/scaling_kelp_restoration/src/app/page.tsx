"use client";

import { useState, useCallback, useEffect } from "react";
import dynamic from "next/dynamic";
import type { DataPoint, LayerName, LayerState, UrchinReport } from "@/types";
import { loadSampleCSV } from "@/utils/sample-data";
import LayerControls from "@/components/LayerControls";
import Legend from "@/components/Legend";
import UrchinReportForm from "@/components/UrchinReportForm";

const MapView = dynamic(() => import("@/components/MapView"), { ssr: false });

const DEFAULT_LAYERS: LayerState = {
  current: {
    name: "Kelp 2025",
    field: "kelp_biomass_kg_2025",
    colorLow: "#064e3b",
    colorHigh: "#22c55e",
    visible: true,
    opacity: 0.8,
  },
  past: {
    name: "Kelp 2015",
    field: "kelp_biomass_kg_past_2015",
    colorLow: "#4a3a00",
    colorHigh: "#f59e0b",
    visible: false,
    opacity: 0.8,
  },
  temperature: {
    name: "Temperature",
    field: "temperature",
    colorLow: "#1e3a5f",
    colorHigh: "#ef4444",
    visible: false,
    opacity: 0.8,
  },
  salinity: {
    name: "Salinity",
    field: "salinity",
    colorLow: "#0c2d48",
    colorHigh: "#38bdf8",
    visible: false,
    opacity: 0.8,
  },
  ocean_current: {
    name: "Ocean Current",
    field: "ocean_current",
    colorLow: "#1a1a2e",
    colorHigh: "#a78bfa",
    visible: false,
    opacity: 0.8,
  },
  composite_score: {
    name: "Composite Score",
    field: "composite_score",
    colorLow: "#3b1a2e",
    colorHigh: "#ec4899",
    visible: false,
    opacity: 0.8,
  },
};

const STORAGE_KEY = "kelp_urchin_reports";

function loadReports(): UrchinReport[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as UrchinReport[]) : [];
  } catch {
    return [];
  }
}

function saveReports(reports: UrchinReport[]) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
  } catch {
    // localStorage unavailable
  }
}

export default function Home() {
  const [data, setData] = useState<DataPoint[]>([]);
  const [layers, setLayers] = useState<LayerState>(DEFAULT_LAYERS);
  const [loading, setLoading] = useState(true);

  const [urchinReports, setUrchinReports] = useState<UrchinReport[]>([]);
  const [urchinLayerVisible, setUrchinLayerVisible] = useState(true);
  const [reportMode, setReportMode] = useState(false);
  const [pendingLocation, setPendingLocation] = useState<{ lat: number; lng: number } | null>(null);

  useEffect(() => {
    loadSampleCSV()
      .then((points) => {
        setData(points);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    setUrchinReports(loadReports());
  }, []);

  const toggleLayer = useCallback((layer: LayerName) => {
    setLayers((prev) => ({
      ...prev,
      [layer]: { ...prev[layer], visible: !prev[layer].visible },
    }));
  }, []);

  const soloLayer = useCallback((layer: LayerName) => {
    setLayers((prev) => {
      const next = { ...prev };
      for (const key of Object.keys(next) as LayerName[]) {
        next[key] = { ...next[key], visible: key === layer };
      }
      return next;
    });
  }, []);

  const setOpacity = useCallback((layer: LayerName, opacity: number) => {
    setLayers((prev) => ({
      ...prev,
      [layer]: { ...prev[layer], opacity },
    }));
  }, []);

  const handleLocationSelected = useCallback((lat: number, lng: number) => {
    setPendingLocation({ lat, lng });
    setReportMode(false);
  }, []);

  const handleReportSubmit = useCallback(
    (report: Omit<UrchinReport, "id" | "timestamp">) => {
      const newReport: UrchinReport = {
        ...report,
        id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
        timestamp: new Date().toISOString(),
      };
      setUrchinReports((prev) => {
        const updated = [...prev, newReport];
        saveReports(updated);
        return updated;
      });
      setPendingLocation(null);
    },
    []
  );

  const totalUrchins = urchinReports.reduce((sum, r) => sum + r.urchin_count, 0);

  return (
    <div className="app-container">
      <aside className="sidebar">
        <div className="sidebar-header">
          <h1>Kelp Restoration Model</h1>
          <p>California Coastline Analysis</p>
          {!loading && (
            <div className="data-badge">{data.length} data points</div>
          )}
          {loading && (
            <div className="data-badge">Loading data&hellip;</div>
          )}
        </div>

        <div className="sidebar-scroll">
          <div className="sidebar-section">
            <h2>Layers</h2>
            <LayerControls
              layers={layers}
              onToggle={toggleLayer}
              onSolo={soloLayer}
              onOpacityChange={setOpacity}
            />
          </div>

          {/* ── Urchin Removal Layer ── */}
          <div className="sidebar-section">
            <h2>Urchin Removal</h2>
            <div className="layer-toggle">
              <input
                type="checkbox"
                checked={urchinLayerVisible}
                onChange={() => setUrchinLayerVisible((v) => !v)}
                data-layer="urchin"
              />
              <div className="layer-info">
                <div className="layer-name-row">
                  <span className="layer-name">Removal Reports</span>
                  {urchinReports.length > 0 && (
                    <span className="urchin-count-badge">
                      {urchinReports.length}
                    </span>
                  )}
                </div>
                <div className="layer-desc">Community urchin removal logs</div>
              </div>
            </div>

            {urchinReports.length > 0 && (
              <div className="urchin-totals">
                <span className="urchin-total-num">{totalUrchins.toLocaleString()}</span>
                <span className="urchin-total-label">total urchins smashed</span>
              </div>
            )}

            <button
              className={`btn-log-removal${reportMode ? " active" : ""}`}
              onClick={() => setReportMode((v) => !v)}
            >
              {reportMode ? "Cancel — click the map" : "+ Log Removal"}
            </button>

            {reportMode && (
              <p className="report-hint">Click anywhere on the map to place a flag</p>
            )}
          </div>

          <div className="sidebar-section">
            <h2>Legend</h2>
            <Legend layers={layers} />
          </div>

          <div className="stats-bar">
            {data.length > 0 ? (
              <>
                <span>{data.length}</span> data points &middot; Lat{" "}
                <span>
                  {Math.min(...data.map((d) => d.latitude)).toFixed(2)}&ndash;
                  {Math.max(...data.map((d) => d.latitude)).toFixed(2)}
                </span>
              </>
            ) : (
              "Loading data\u2026"
            )}
          </div>
        </div>
      </aside>

      <main className="map-wrapper">
        <MapView
          data={data}
          layers={layers}
          reportMode={reportMode}
          urchinLayerVisible={urchinLayerVisible}
          urchinReports={urchinReports}
          onLocationSelected={handleLocationSelected}
        />
      </main>

      {pendingLocation && (
        <UrchinReportForm
          latitude={pendingLocation.lat}
          longitude={pendingLocation.lng}
          onSubmit={handleReportSubmit}
          onCancel={() => setPendingLocation(null)}
        />
      )}
    </div>
  );
}
